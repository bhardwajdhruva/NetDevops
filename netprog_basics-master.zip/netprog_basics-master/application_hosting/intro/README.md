# Application Hosting and the Network
## Local Setup
This lesson has no setup requirements.

## Download Slides

You can download the slides for this lesson [here](https://developer.cisco.com/fileMedia/download/a012b8b7-0896-3b61-a06a-5c0e61f58f89). 

> *Suggestion: Right click, "Open in new tab"*