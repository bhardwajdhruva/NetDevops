# How to be a Network Engineer in a Programmable Age
## Local Setup
This lesson has no setup requirements.

## Download Slides

You can download the slides for this lesson [here](https://developer.cisco.com/fileMedia/download/6059a87f-040c-3922-baeb-6d7bc878dab6). 

> *Suggestion: Right click, "Open in new tab"*