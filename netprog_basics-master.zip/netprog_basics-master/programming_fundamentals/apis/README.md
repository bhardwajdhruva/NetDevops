# APIs are Everywhere... but what are they?
## Local Setup
This lesson has no setup requirements.

## Download Slides

You can download the slides for this lesson [here](https://developer.cisco.com/fileMedia/download/67578642-b07f-3007-97f9-3c222842237c). 

> *Suggestion: Right click, "Open in new tab"*