This directory will be used to hold Ansible generated configuration files during execution.  
