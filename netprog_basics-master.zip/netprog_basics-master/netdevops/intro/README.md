# Configuration Management and the Network
## Local Setup
This lesson has no setup requirements.

## Download Slides

You can download the slides for this lesson [here](https://developer.cisco.com/fileMedia/download/d7833ac8-be49-379d-b7d6-04d4a39b67be). 

> *Suggestion: Right click, "Open in new tab"*